package hu.mocman.java.elsofelev;

import org.junit.Test;

import static org.junit.Assert.assertNotEquals;

public class testLeltár {
    @Test
    public void testMennyiség() {
        /*
        Alapanyag alma = new Alapanyag(Mennyiség.darab(5), "alma");
        Alapanyag körte = new Alapanyag(Mennyiség.darab(6), "körte");
        assertNotEquals(alma.mennyiség, körte.mennyiség);
        */
    }
}
