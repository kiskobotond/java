package hu.mocman.java.elsofelev;

import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.util.Objects;

/**
 * Ez a fájl tartalmazza a feladatot. Ne módosítsd a kódot, csak a kikommentezett részeket szedd le róla!<br />
 * A feladat:<br />
 * <ul>
 * <li>Készítsd el a <b>Mennyiség</b> class-t! Ez szolgál a mennyiségek tárolására. Minden mértékegységhez tartalmazza a
 * pontos mennyiséget (double). A különböző típusú mennyiségek kerüljenek különböző típusokba! (lásd öröklődés)</li>
 * <li>Készítsd el a <b>Konyha</b> osztályt! Ez szolgál a konyhában található alapanyagok tárolására.</li>
 * <li>Segítségként készíts egy <b>Alapanyag</b> osztályt! Az osztály tartalmazza a mennyiséget és a megnevezést!</li>
 * <li>A konyha felhasznál alapanyagokat, és így azokkal csökken a konyha tartalma!</li>
 * </ul>
 * Figyelj oda, hogy a mennyiségek nem érzékenyek a kis- és nagybetűkre, valamint a szó eleji és végi szóközökre!<br />
 * A <b>konyha.txt</b>-ben találod a példa adatokat, amikkel az osztályozás történik!<br />
 * A program futtatásakor a jegyed automatikusan kiíratódik a standard outputra!<br />
 * @author Várkonyi Tibor 2018
 */
public class Main {
    /**
     * Visszaadja egy resource file helyét
     * @param path az erőforrás neve
     * @return az erőforrás helye
     * @throws URISyntaxException ha nem elérhető
     */
    private static String getResourcePath(String path) throws URISyntaxException {
        return Paths.get(Objects.requireNonNull(Main.class.getClassLoader().getResource(path)).toURI()).toString();
    }
    public static void main(String[] args) {
        int jegy = 1;
        try {
            String konyhaLeltár = getResourcePath("konyha.txt");

            Konyha konyha = new Konyha();
            konyha.beolvas(konyhaLeltár);

            /*
            // Kettesért
            if (konyha.mennyiVan("Tojás").equals(Mennyiség.darab(2)) &&
                    konyha.mennyiVan("tojás").equals(Mennyiség.darab(2))) {
                jegy++;
            }

            // Hármasért
            if (konyha.mennyiVan(" cuKor ").equals(Mennyiség.gramm(2000)) &&
                    konyha.mennyiVan("cukor").equals(Mennyiség.kilogramm(2)) &&
                    konyha.mennyiVan("liszt").equals(Mennyiség.gramm(1250))) {
                jegy++;
            }

            // Négyesért
            if (konyha.mennyiVan("tej 2.8%").equals(Mennyiség.liter(1)) &&
                    konyha.mennyiVan("tej 1.5%").equals(Mennyiség.liter(1)) &&
                    konyha.mennyiVan("pisztácia").equals(Mennyiség.gramm(0)) &&
                    konyha.mennyiVan("pisztácia").equals(Mennyiség.liter(0)) &&
                    konyha.mennyiVan("csokoládé").equals(Mennyiség.semennyi())) {
                jegy++;
            }

            // Ötösért
            Alapanyag tojások = new Alapanyag(Mennyiség.darab(2), "tojás");
            try {
                konyha.felhasznál(tojások);
                if (konyha.mennyiVan("tojás").equals(Mennyiség.darab(0))) {
                    try {
                        Alapanyag cukor = new Alapanyag(Mennyiség.kilogramm(3), "cukor");
                        konyha.felhasznál(cukor);
                    }catch (NincsElégAlapanyagException e) {
                        if (e.miből.equals("cukor") && e.mennyiKell().equals(Mennyiség.kilogramm(1))) {
                            jegy++;
                        }
                    }
                }
            } catch (NincsElégAlapanyagException ex) {
                ex.printStackTrace();
            }
            */

        } catch (URISyntaxException e) {
            e.printStackTrace();
        } finally {
            System.out.println("A jegyed = " + jegy);
        }
    }
}
