package hu.mocman.java.elsofelev;

public class Konyha {
    public void beolvas(String konyhaLeltár) {

    }
}
