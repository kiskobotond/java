package hu.mocman.relay;

import java.util.Vector;

/**
 * hu.mocman.relay.RelayRunner
 * Feladata, hogy a Relay osztályt ellenőrizze, ami egy üzenetszórást megvalósító osztály
 * A Relay-t a következőképpen lehet használni:
 * - Kell egy MessageSender interface, ami üzenetet tud küldeni
 * - Kell egy MessageReceiver interface, ami üzenetet tud fogadni
 * - Az üzenet egy Message típus, ami egy String-et tartalmaz.
 * - Készíts egy üzenet készítő osztályt, ami a MessageFactory!
 * - A Relay ha kap egy üzenetet, azt továbbítania kell az összes felirakozott objektumnak
 *
 *
 *
 *  * - A Relaybe be lehet csatlakozni MessageReceiver típusú objektummal
 *
 *
 * - A Relay mindkettőt megvalósítja
 * - A Relayből ki lehet szedni MessageReceiver típusú objektumot
 */
public class RelayRunner implements MessageReceiver {

    private static int jegy = 1;
    private final static Vector<RelayRunner> runners = new Vector<>();
    private final static int numberOfRunners = 8;
    private String message;

    private RelayRunner() {
        resetMessage();
    }

    public static void main(String[] args) {
        try {

            /*
            // Kettesért
            final Message helloMessage = MessageFactory.createMessage("Hello");
            final MessageReceiver receiver = new MessageReceiver() {
                public void receive(Message message) {
                    if (message.equals(helloMessage)) {
                        jegy = 2;
                    }
                }
            };
            final MessageSender sender = new MessageSender() {
                public void send(Message message) {
                  receiver.receive(MessageFactory.createMessage(message.message));
                }
            };
            sender.send(helloMessage);


            // Hármasért
            for (int i = 0; i < numberOfRunners; i++) {
                runners.add(new RelayRunner());
            }
            resetMessages();
            Relay relay = new Relay();
            relay.addReceiver(runners.get(0));
            relay.send(helloMessage);
            if (runners.get(0).getMessage().equals("Hello") &&
                    runners.get(1).getMessage().equals("")) {
                jegy = 3;
            }

            // Négyesért
            resetMessages();
            relay.addReceiver(runners.get(1));
            relay.addReceiver(runners.get(2));
            relay.removeReceiver(runners.get(1));
            relay.send(helloMessage);
            if (runners.get(0).getMessage().equals("Hello") &&
                    runners.get(1).getMessage().equals("") &&
                    runners.get(2).getMessage().equals("Hello")) {
                jegy = 4;
            }
            */

            /*
            // Ötösért
            resetMessages();
            Relay relay2 = new Relay();
            relay.addReceiver(relay2);
            relay2.addReceiver(runners.get(3));
            relay2.addReceiver(runners.get(4));
            relay2.addReceiver(runners.get(5));
            relay2.removeReceiver(runners.get(0));
            relay.send(helloMessage);
            if (runners.get(0).getMessage().equals("Hello") &&
                    runners.get(1).getMessage().equals("") &&
                    runners.get(2).getMessage().equals("Hello") &&
                    runners.get(3).getMessage().equals("Hello") &&
                    runners.get(4).getMessage().equals("Hello") &&
                    runners.get(5).getMessage().equals("Hello")) {
                jegy = 5;
            }
            */

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("A jegyed = " + jegy);
    }

    @Override
    public void receive(Message message) {
        this.message = message.message;
    }

    private String getMessage() {
        return message;
    }

    private void resetMessage() {
        message = "";
    }

    private static void resetMessages() {
        for (RelayRunner runner : runners) {
            runner.resetMessage();
        }
    }
}
