package hu.mocman.relay;

public class MessageFactory {

    public static Message createMessage(String hello) {
        return null;
    }
}


