package hu.mocman.relay;

public interface MessageSender {
    void send(Message helloMessage);
}
