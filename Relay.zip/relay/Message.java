package hu.mocman.relay;


public class Message {
    public Message(String text) {
    }

}

