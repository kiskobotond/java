package hu.mocman.relay;

public class Relay {
    public void addReceiver(RelayRunner relayRunner) {
    }
    public void send(Message helloMessage) {
    }
}