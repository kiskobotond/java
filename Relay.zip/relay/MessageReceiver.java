package hu.mocman.relay;

public interface MessageReceiver {
    void receive(Message message);
}
